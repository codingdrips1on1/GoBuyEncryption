<?php
 echo 'Hello, world!' 
?>