<?php
 echo 'Hello, world!' 
? >